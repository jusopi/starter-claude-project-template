---
name: update-notion-project
description: Update a project's existing Notion pages (Backlog, Activity Log, Design Decisions, Open Discussions, and — for ai-only projects — Instructions) with new context or decisions from the current conversation. Use when the user says things like "update the project," "sync Notion," "add that to the backlog/decisions," or at the end of a session/after a major decision to offer an update.
---

# Update Notion Project Pages

This skill governs ongoing maintenance of a project's Notion workspace once
it exists. If the workspace doesn't exist yet, use the
`bootstrap-notion-project` skill first to create it.

A Notion-tracked project has a hub page with Backlog, Activity Log, Design
Decisions, and Open Discussions as its core sub-pages, plus an Instructions
page for projects that are still `ai-only` (no paired code repo yet):

- **Instructions page** — standing context/rules for the project: what it
  is, core philosophy, current scope, working conventions. Functions like a
  `CLAUDE.md` would in a code project. Only exists for projects that are
  still `ai-only`; once a code repo is linked, `CLAUDE.md` takes over this
  role and this page is no longer actively maintained (see the note left on
  it at that transition).
- **Activity Log page** — prose only: a current-state summary plus a
  per-session changelog (newest-first).
- **Backlog page** — the single flat checklist of open work. This is the
  *only* place open TODOs/unfinished work live, project-wide.
- **Design Decisions page** — locked decisions only.
- **Open Discussions page** — ongoing, inconclusive, topic-based threads
  with no defined next action and no resolution yet. An item stays here
  only while genuinely unresolved. It graduates out exactly once — move it
  to Backlog once it becomes a concrete actionable item, or to Design
  Decisions once it's settled — and remove it from Open Discussions at that
  point. Never leave an item on both pages after it graduates.

There are two ways an update happens:

**User-initiated:** if the user says something like *"update the project,"*
*"sync Notion,"* or *"add that to the backlog/decisions,"* treat it as a
direct instruction — summarize what changed, propose the specific edit, and
write it once confirmed.

**Claude-solicited:** at the end of a substantive session, or after a major
decision/milestone, ask: *"Want me to update the project pages with what we
covered today?"* Wait for a yes before writing anything. Don't solicit more
than once per session unless something changed after the first ask.

## Session start — bootstrap from Notion

Notion pages are **not** automatically loaded into context the way a
project's custom instructions or `CLAUDE.md` would be — nothing happens
unless this skill explicitly triggers it.

At the start of a new conversation on a Notion-tracked project (first user
message, or the first time project-related work comes up), check this
project's Project Links row status first:

- **`ai-only`:** proactively fetch that project's Instructions page before
  doing anything else project-related. This re-establishes standing context
  the same way `CLAUDE.md` auto-loads in Claude Code.
- **`linked` (or `code-only`/`stale`):** skip the Instructions fetch — an
  Instructions page may not exist at all for this project (see the page-set
  note above), and even where a stale one exists from an earlier `ai-only`
  period, `CLAUDE.md` in the code repo is the current standing-context
  source, not this page. Don't proactively fetch or flag it.

- Don't wait to be asked — treat "we're picking this project back up" as
  the trigger for whichever of the above applies.
- If the conversation's first message is clearly unrelated to any tracked
  project, skip the fetch until project work actually comes up.
- Only fetch the other pages (Backlog, Activity Log, Design Decisions, Open
  Discussions) on demand, when the conversation actually needs them — don't
  pull all of them proactively every session just in case.
- If a user is working across *multiple* Notion-tracked projects, confirm
  which project's hub page to fetch if it isn't obvious from context.

## Hard rules

- **Never write to any Notion page without an explicit go-ahead from the
  user first.** Present the proposed additions/removals/edits as a plan in
  chat (what's changing, on which page, and why) and wait for confirmation
  before calling any Notion write tool.
- **Preserve links between pages.** The hub page links out to the four core
  pages (and any others added later). Never remove or silently break one of
  those links during an update — carry them forward untouched unless the
  user explicitly asks to remove one.
- **If this project is `ai-only` and its Instructions page still contains a
  placeholder/stub**, that means the `bootstrap-notion-project` intake
  hasn't fully happened yet — flag this and offer to run that setup instead
  of patching the stub incrementally. If this project is `linked` (or later
  transitions to `linked`), don't apply this check at all — Instructions
  may not exist, and that's expected, not a stub to flag.

## What counts as "project state"

What belongs on the Instructions page varies by project type — a software
project tracks different things than a creative-writing project or a
business idea. Only track categories that actually apply to *this*
project, rather than guessing or importing categories from a different
project.

Regardless of project type, one thing is constant: **open TODOs/unfinished
work never get their own Instructions-page section.** That category has a
single dedicated home — the Backlog page. If you're about to write "next
steps" or "still to figure out" prose into Instructions, stop and route it
to Backlog instead. Instructions may still contain narrative continuity
about a *currently active* topic (why it's undecided, scope notes, context
a future session needs) — that's not a checklist, it's the story behind one
line in the backlog.

## Noticing drift

At the Claude-solicited checkpoint, do a cheap staleness check before
asking — don't just fire the generic prompt every time:

- Compare what was actually discussed/decided in the current conversation
  against what's already written on the Design Decisions and Backlog
  pages.
- If something discussed this session contradicts or supersedes something
  already written, name that specific gap when soliciting the update
  instead of asking generically (e.g., "we changed our mind on X since
  Design Decisions still says Y — want me to update that too?").
- Reconcile sections, not just facts: **add** a section for a topic that
  now applies but isn't documented yet, **remove** a section whose topic no
  longer applies, and **update** a section whose content is stale but still
  relevant. Propose all three kinds of changes together rather than only
  ever appending.
- This only changes *what you ask* — the hard rule still applies: never
  write without explicit go-ahead.
- **Self-report the drift check itself**, every run: when proposing the
  plan, include a visible summary of which pages were checked and the
  finding for each — including an explicit "no drift" where nothing was
  found — not just the resulting proposed edits.

**Full drift-pass, not just session-triggered:** don't only check Design
Decisions against *this session's* work — that misses staleness in
sections nobody touched recently. At every Claude-solicited checkpoint, do
one pass over the full Design Decisions page, not just the parts relevant
to today, and flag anything that contradicts current reality even if this
session didn't cause it.

## Keeping the Backlog, Activity Log, and Open Discussions pages in sync

Treat every run of this skill as a pass over the whole page set, not just
the Instructions page:

- **Backlog page** — check off items the session's work resolved, add any
  new items it surfaced, and re-prioritize if the session changed what's
  next. Do not create or maintain a second checklist anywhere else.
- **Activity Log page** — prose only: current-state summary + a
  per-session changelog entry (newest-first). No checklist section belongs
  here — if about to write a checkbox-style item into this page, it
  belongs on Backlog instead.
- **Design Decisions page** — locked decisions only. If the session's work
  resolved, added, or contradicted something documented there, flag it and
  propose the edit. If a "decision" there is actually still open (a
  flagged risk, a deferred alternative, an unresolved question), that's a
  backlog item wearing the wrong hat — propose moving it to Backlog rather
  than leaving it here.
- **Open Discussions page** — this is where ongoing, inconclusive,
  topic-based ideas live while they're still unresolved across sessions,
  with no defined next action yet. During this sync pass: if the session's
  work turned an Open Discussions item into something actionable, move it
  to Backlog and remove it from Open Discussions. If the session's work
  settled/resolved an Open Discussions item, move it to Design Decisions
  and remove it from Open Discussions. An item graduates out exactly once,
  into exactly one of those two pages — never leave it on Open Discussions
  after it's moved, and never let it land on both Backlog and Design
  Decisions at once.
- Bundle all of it — Instructions (if it exists for this project), Backlog,
  Activity Log, Design Decisions, and Open Discussions if any need a touch
  — into the **same** proposed plan and the same go-ahead. Don't get
  approval on one page alone and then separately edit the others unprompted
  afterward.

## Note on the ai-only → linked transition

When a project moves from `ai-only` to `linked` (a code repo now exists),
the code-side `link-project` skill — not this skill — appends a short note
to that project's Instructions page: "Code project now exists; CLAUDE.md is
the current source of truth for this project going forward." This skill
should not attempt to add that note itself, and should not treat its
presence as a stub/placeholder needing the bootstrap flag above.

## Notion-specific mechanics

- Fetch current page content before proposing an edit — never propose
  changes from memory alone, since the page may have been edited outside
  this conversation.
- Prefer targeted content updates or appends over full-page replacement
  where possible, to avoid accidentally clobbering unrelated sections.
- Treat each page as its own isolated edit target — fetch and update only
  the specific page(s) relevant to the proposed change, not the whole hub
  tree at once.
- If working across multiple Notion-tracked projects, always confirm which
  project's pages are the target before writing, since page names
  (Instructions, Backlog, etc.) repeat across projects.
