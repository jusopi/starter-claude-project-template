---
name: bootstrap-notion-project
description: Set up a new project's Notion-based living-documentation workspace (a hub page plus Instructions, Backlog, Activity Log, and Design Decisions sub-pages), and create or update that project's row in the Project Links database. Use when the user says things like "set up the Notion workflow for this project," "bootstrap this like [other project]," "create the Notion pages for this new project," or "I want to use the same project-tracking setup as [X] for this new idea."
---

# Bootstrap a Notion Project Workspace

This skill creates the initial Notion workspace for a new project, using the
same four-page pattern regardless of what kind of project it is (tabletop
ruleset, software, business idea, creative writing, research, etc.). It is
paired with the **update-notion-project** skill, which governs ongoing
maintenance of that workspace once it exists — this skill only handles the
one-time setup.

It also creates or updates this project's row in the **Project Links**
database — the hub that pairs an ai Project with a code repo (see Step 4).

## When this fires

Trigger on requests like:
- "Set up the Notion workflow for this project"
- "Bootstrap this project the way we did [other project]"
- "Create the Notion pages for this new project"
- "I want the same tracking setup as [X] but for [new idea]"

Do **not** fire this for routine updates to an already-existing workspace —
that's the `update-notion-project` skill's job. If Notion search turns up an
existing hub page for this project already, stop and hand off to
`update-notion-project` instead of re-creating pages.

## Step 1 — Gather project context

Before creating anything, get (by asking, or from what's already been
discussed in the conversation):

- **Project name** — used as the hub page title, and as the lookup/join key
  for the Project Links row (Step 4)
- **One-line description** — what the project actually is
- **Project type** — tabletop/creative/software/business/research/other —
  this determines what "project state" categories make sense later (see
  Step 3)
- **Current stage** — brand new with nothing decided yet, mid-brainstorm in
  this conversation, or migrating from existing notes/docs the user will
  paste in
- **Source material** — any existing brainstorming, transcripts, or docs to
  seed the pages from. If none, that's fine — pages can start mostly empty.
- **Is there (or will there be) a code repo for this?** — determines the
  Project Links row's status in Step 4. If yes and the repo URL is already
  known, get it now.

Don't ask all of this as a rigid questionnaire if the user has already
supplied it in their message — only ask for what's actually missing.

## Step 2 — Check for an existing workspace first

Before proposing anything, search Notion for a page matching the project
name to confirm one doesn't already exist. If one does, stop here and
suggest using `update-notion-project` instead.

## Step 3 — Propose the structure before creating anything

Always propose before writing. Show the user:

- The hub page name
- The four sub-pages (Instructions, Backlog, Activity Log, Design
  Decisions) and what will go on each, adapted to this project's actual
  type — the specific "project state" categories on the Instructions page
  should fit the project (e.g., a software project needs "tech stack &
  dependencies," a creative-writing project needs "characters & world
  rules" instead, a business idea needs "audience & stage")
- If source material was provided, a reconciled/organized draft of what
  each page would contain — never paste raw source material verbatim
  without organizing it into the right page and section

Wait for explicit confirmation before creating any Notion page. This
mirrors the no-write-without-go-ahead rule that governs all later updates
too (see the `update-notion-project` skill).

## Step 4 — Create the workspace

Once confirmed:

1. Create the hub page (project name as title), with a one-line description
   and a placeholder note that links will be added once sub-pages exist.
2. Create the four sub-pages as children of the hub page:
   - **Instructions** — standing context: what the project is, core
     philosophy/principles, audience/stage, current scope/milestone,
     working conventions. This is the page a new conversation should read
     first to re-establish context (see the session-start bootstrap logic
     in `update-notion-project`). For a project with a paired code repo,
     `CLAUDE.md` is that repo's own standing-context doc — Instructions
     here is not a mirror of it, just the equivalent for the Notion/ai
     side.
   - **Backlog** — the single flat checklist of open/unfinished work. No
     other page should duplicate this.
   - **Activity Log** — prose only: a current-state summary plus a
     per-session changelog (newest-first). No checklist belongs here.
   - **Design Decisions** — locked decisions only, organized under headings
     that make sense for this project's actual content areas. Not a place
     for open questions — those go on the Backlog page.
3. Update the hub page to add working links to all four sub-pages.
4. Create or update this project's row in the **Project Links** database
   (columns: Project Name, AI Project URL, Code Repo URL, Link Status,
   Last Synced, plus relations to this project's Backlog / Activity Log /
   Design Decisions pages):
   - Look up by project name first — never create a duplicate row.
   - If no code repo exists yet (per Step 1), create/update the row with
     `Link Status` = `ai-only`, `AI Project URL` filled in, `Code Repo URL`
     left blank.
   - If a code repo URL is already known, create/update the row with
     `Link Status` = `linked`, both URLs filled in.
   - Either way, set `Last Synced` to today and link the relation
     properties to the Backlog/Activity Log/Design Decisions pages just
     created.

## Step 5 — Confirm and hand off

Tell the user the workspace is live, link the hub page, note the Project
Links row's current status, and note that ongoing updates going forward
should go through the `update-notion-project` skill (which they should also
have installed/uploaded).

## Reuse notes

- This skill is intentionally project-agnostic. Nothing about a specific
  project (its name, its subject matter, its category list) should be
  hardcoded into this file — all of that comes from Step 1's context
  gathering and gets tailored fresh each time this skill runs.
- If the project doesn't cleanly need one of the four standard pages, or
  needs an additional page (e.g., "Characters," "Research Sources," "API
  Reference"), propose that adjustment in Step 3 rather than forcing every
  project into an identical four-page mold.
