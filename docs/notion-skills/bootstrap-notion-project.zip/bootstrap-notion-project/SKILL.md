---
name: bootstrap-notion-project
description: Set up a new project's Notion-based living-documentation workspace (a hub page plus Instructions, Backlog, Activity Log, and Design Decisions sub-pages). Use when the user says things like "set up the Notion workflow for this project," "bootstrap this like [other project]," "create the Notion pages for this new project," or "I want to use the same project-tracking setup as [X] for this new idea."
---

# Bootstrap a Notion Project Workspace

This skill creates the initial Notion workspace for a new project, using the
same four-page pattern regardless of what kind of project it is (tabletop
ruleset, software, business idea, creative writing, research, etc.). It is
paired with the **update-notion-project** skill, which governs ongoing
maintenance of that workspace once it exists — this skill only handles the
one-time setup.

**Exception:** a project using the **sync-notion** pattern (a Claude Code
repo whose `CLAUDE.md` mirrors into Notion — see "sync-notion-managed
projects" below) is bootstrapped differently and is *not* handed off to
`update-notion-project` afterward. Check for this before assuming the
default flow applies.

## When this fires

Trigger on requests like:
- "Set up the Notion workflow for this project"
- "Bootstrap this project the way we did [other project]"
- "Create the Notion pages for this new project"
- "I want the same tracking setup as [X] but for [new idea]"

Do **not** fire this for routine updates to an already-existing workspace —
that's the `update-notion-project` skill's job. If Notion search turns up an
existing hub page for this project already, stop and hand off to
`update-notion-project` instead of re-creating pages.

## Step 1 — Gather project context

Before creating anything, get (by asking, or from what's already been
discussed in the conversation):

- **Project name** — used as the hub page title
- **One-line description** — what the project actually is
- **Project type** — tabletop/creative/software/business/research/other —
  this determines what "project state" categories make sense later (see
  Step 3)
- **Current stage** — brand new with nothing decided yet, mid-brainstorm in
  this conversation, or migrating from existing notes/docs the user will
  paste in
- **Source material** — any existing brainstorming, transcripts, or docs to
  seed the pages from. If none, that's fine — pages can start mostly empty.
- **sync-notion pattern?** — if the project is a software project with a
  `CLAUDE.md`-based repo, ask (or check the repo directly if you have file
  access) whether it already has, or wants, a `### Notion workspace`
  heading in `CLAUDE.md`. If so, this is a **sync-notion-managed project**
  — see the dedicated section below, which changes Steps 3 and 4 and skips
  the Step 5 hand-off to `update-notion-project` entirely.

Don't ask all of this as a rigid questionnaire if the user has already
supplied it in their message — only ask for what's actually missing.

## Step 2 — Check for an existing workspace first

Before proposing anything, search Notion for a page matching the project
name to confirm one doesn't already exist. If one does, stop here and
suggest using `update-notion-project` instead — unless this is a
sync-notion-managed project (see below), in which case suggest `sync-notion`
instead, since `update-notion-project`'s write model doesn't apply there.

## Step 3 — Propose the structure before creating anything

Always propose before writing. Show the user:

- The hub page name
- The four sub-pages (Instructions, Backlog, Activity Log, Design
  Decisions) and what will go on each, adapted to this project's actual
  type — the specific "project state" categories on the Instructions page
  should fit the project (e.g., a software project needs "tech stack &
  dependencies," a creative-writing project needs "characters & world
  rules" instead, a business idea needs "audience & stage")
- If source material was provided, a reconciled/organized draft of what
  each page would contain — never paste raw source material verbatim
  without organizing it into the right page and section

**Exception for sync-notion-managed projects:** skip the "organize source
material into each page" step described above entirely. The four pages
will be pushed-to mirrors of `CLAUDE.md`/`docs/backlog.md`/
`docs/activity-log.md`/`docs/design-decisions.md`, not independently
adapted content — propose creating them as near-empty placeholders instead
(see Step 4), since the first `sync-notion` push (via `update-claude`)
overwrites them with the real local-file content anyway. Don't spend effort
reconciling or organizing anything for these four pages.

Wait for explicit confirmation before creating any Notion page. This
mirrors the no-write-without-go-ahead rule that governs all later updates
too (see the `update-notion-project` skill).

## Step 4 — Create the workspace

Once confirmed:

1. Create the hub page (project name as title), with a one-line description
   and a placeholder note that links will be added once sub-pages exist.
2. Create the four sub-pages as children of the hub page:
   - **Instructions** — standing context: what the project is, core
     philosophy/principles, audience/stage, current scope/milestone,
     working conventions. This is the page a new conversation should read
     first to re-establish context (see the session-start bootstrap logic
     in `update-notion-project`).
   - **Backlog** — the single flat checklist of open/unfinished work. No
     other page should duplicate this.
   - **Activity Log** — prose only: a current-state summary plus a
     per-session changelog (newest-first). No checklist belongs here.
   - **Design Decisions** — locked decisions only, organized under headings
     that make sense for this project's actual content areas. Not a place
     for open questions — those go on the Backlog page.
3. Update the hub page to add working links to all four sub-pages.

**Exception for sync-notion-managed projects:** create all four sub-pages
with minimal placeholder content only (e.g. "Content pending first sync —
see `sync-notion`"), not adapted/organized prose. Also note for the user
that a fifth page, `notion-to-code-sync`, will be created automatically by
`sync-notion` on its first run (as a queue page for Claude.ai-side ideas)
— this skill doesn't need to create it itself.

## Step 5 — Confirm and hand off

Tell the user the workspace is live, link the hub page, and note that
ongoing updates going forward should go through the `update-notion-project`
skill (which they should also have installed/uploaded).

**Exception for sync-notion-managed projects:** do not mention
`update-notion-project` at all. Instead tell the user that ongoing sync for
this workspace goes through `sync-notion`, invoked automatically from the
`update-claude` skill on the Claude Code side, and that they'll still need
to complete the one-time Notion MCP connection step (`docs/notion-mcp-setup.md`
in the project repo) before any sync can actually run.

## Reuse notes

- This skill is intentionally project-agnostic. Nothing about a specific
  project (its name, its subject matter, its category list) should be
  hardcoded into this file — all of that comes from Step 1's context
  gathering and gets tailored fresh each time this skill runs.
- If the project doesn't cleanly need one of the four standard pages, or
  needs an additional page (e.g., "Characters," "Research Sources," "API
  Reference"), propose that adjustment in Step 3 rather than forcing every
  project into an identical four-page mold.
- The sync-notion exception above is the one case where this skill
  deliberately does *not* adapt page content — everything else about the
  four-page pattern (names, hierarchy, hub linking) still applies.
