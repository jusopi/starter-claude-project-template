---
name: update-notion-project
description: Update a project's existing Notion pages (Instructions, Backlog, Activity Log, Design Decisions) with new context or decisions from the current conversation. Use when the user says things like "update the project," "sync Notion," "add that to the backlog/decisions," or at the end of a session/after a major decision to offer an update. Does not apply to a sync-notion-managed project (see below) — check for that first.
---

# Update Notion Project Pages

This skill governs ongoing maintenance of a project's Notion workspace once
it exists. If the workspace doesn't exist yet, use the
`bootstrap-notion-project` skill first to create it.

A Notion-tracked project has a hub page with four core sub-pages:

- **Instructions page** — standing context/rules for the project: what it
  is, core philosophy, current scope, working conventions. Functions like a
  `CLAUDE.md` would in a code project.
- **Activity Log page** — prose only: a current-state summary plus a
  per-session changelog (newest-first).
- **Backlog page** — the single flat checklist of open work. This is the
  *only* place open TODOs/unfinished work live, project-wide.
- **Design Decisions page** — locked decisions only.

There are two ways an update happens:

**User-initiated:** if the user says something like *"update the project,"*
*"sync Notion,"* or *"add that to the backlog/decisions,"* treat it as a
direct instruction — summarize what changed, propose the specific edit, and
write it once confirmed.

**Claude-solicited:** at the end of a substantive session, or after a major
decision/milestone, ask: *"Want me to update the project pages with what we
covered today?"* Wait for a yes before writing anything. Don't solicit more
than once per session unless something changed after the first ask.

## Before anything else — check for a sync-notion-managed project

Some projects' Notion workspaces are managed by a different skill entirely:
`sync-notion`, which runs from the Claude Code side of a repo and pushes
full, verbatim copies of local files (`CLAUDE.md`,
`docs/backlog.md`/`docs/activity-log.md`/`docs/design-decisions.md`) into
the four mirror pages. That write model — local file always wins, full
replace only — is incompatible with this skill's targeted, conversation-driven
live edits. If both skills touched the same pages, this skill's edits would
just be silently overwritten by the next `sync-notion` push.

**The signal to check for:** when you fetch the Instructions page (per
"Session start" below, or at any point before proposing a write), look for
a line containing the exact text `` `sync-notion:managed` `` (an inline-code
span, mirrored verbatim from that project's `CLAUDE.md`). This is a fixed
marker, not a phrase to paraphrase-match — check for the literal substring,
not for wording that resembles it.

- **Marker found:** stop. Tell the user plainly that this workspace is
  managed by `sync-notion` (invoked from `update-claude` on the Claude Code
  side, not from here), and that editing these pages directly from this
  skill would just get overwritten on the next sync. Don't propose an edit,
  don't ask for a go-ahead — there's nothing this skill should do to a
  sync-notion-managed workspace's four mirror pages. (You can still help
  the user append to that project's `notion-to-code-sync` queue page — see
  the dedicated section below, which is a different, compatible kind of
  write.)
- **A `### Notion workspace`-style heading exists but the marker doesn't**
  (e.g. the heading's there but no `` `sync-notion:managed` `` line, or
  the page content is ambiguous): don't guess either way. Tell the user
  what you found and ask directly whether this workspace is
  sync-notion-managed before proceeding — a wrong assumption in either
  direction is worse than a short clarifying question.
- **No such heading at all:** proceed with this skill's normal flow below.

If the user wants something changed in a sync-notion-managed project's
mirror pages, that request belongs in the project's repo (as a
`CLAUDE.md`/backlog/etc. edit, synced outward from there), or as a raw
entry appended to that project's `notion-to-code-sync` queue page if
they're away from the repo — see the next section.

## Appending to a project's notion-to-code-sync queue

This applies only to sync-notion-managed projects (per the check above).
If the user wants to leave something for Claude Code to pick up later —
a stray idea, a bug they noticed, a mid-conversation instruction that came
up while away from the repo — append it to that project's
`notion-to-code-sync` page rather than touching any of the four mirror
pages.

**Trigger this** when the user says something like *"note this for when
I'm back at the repo,"* *"add this to the queue,"* *"jot this down for
Claude Code,"* or when a substantive new idea/instruction comes up
mid-conversation on a sync-notion-managed project with no live Claude Code
session to hand it to directly.

**Mechanics:**
- Fetch `notion-to-code-sync`. If it doesn't exist yet, say so and suggest
  the user run a repo-side sync first (`sync-notion` owns creating this
  page on its first pull — don't create it yourself here, to avoid two
  skills maintaining the same page's structure independently).
- **Append, never overwrite or edit existing entries.** Add a new, dated
  entry (e.g. a `### YYYY-MM-DD` heading) containing the user's raw
  content — in their own words, not rewritten into "current state"
  language and not summarized down to just the gist. Raw fidelity here is
  what lets `sync-notion`'s pull step surface it faithfully later, since
  the person deciding what to do with it (the user, in a future Claude
  Code session) needs to see what was actually said, not your paraphrase
  of it.
- Confirm the exact entry text with the user before writing, same as any
  other Notion write this skill makes.
- **Never mark an entry `[ingested — date]` yourself.** That status is
  `sync-notion`'s to set, once Claude Code actually processes the entry —
  marking it from this side would claim a decision this skill didn't
  actually make.

Everything below this section describes the normal flow for a project
*without* that marker.

## Session start — bootstrap from Notion

Notion pages are **not** automatically loaded into context the way a
project's custom instructions or `CLAUDE.md` would be — nothing happens
unless this skill explicitly triggers it.

At the start of a new conversation on a Notion-tracked project (first user
message, or the first time project-related work comes up), proactively
fetch that project's **Instructions page** before doing anything else
project-related. This re-establishes standing context the same way
`CLAUDE.md` auto-loads in Claude Code — and, per the check above, is also
where you'd discover a sync-notion marker before going any further.

- Don't wait to be asked — treat "we're picking this project back up" as
  the trigger.
- If the conversation's first message is clearly unrelated to any tracked
  project, skip the fetch until project work actually comes up.
- Only fetch the other three pages (Backlog, Activity Log, Design
  Decisions) on demand, when the conversation actually needs them — don't
  pull all four proactively every session just in case.
- If a user is working across *multiple* Notion-tracked projects, confirm
  which project's hub page to fetch if it isn't obvious from context.

## Hard rules

- **Never write to any Notion page without an explicit go-ahead from the
  user first.** Present the proposed additions/removals/edits as a plan in
  chat (what's changing, on which page, and why) and wait for confirmation
  before calling any Notion write tool.
- **Preserve links between pages.** The hub page links out to the four core
  pages (and any others added later). Never remove or silently break one of
  those links during an update — carry them forward untouched unless the
  user explicitly asks to remove one.
- **If the Instructions page still contains a placeholder/stub**, that
  means the `bootstrap-notion-project` intake hasn't fully happened yet —
  flag this and offer to run that setup instead of patching the stub
  incrementally.
- **Never run against a sync-notion-managed project** — see the check
  above. This rule sits above all the others in this list; check for the
  marker before anything else applies.

## What counts as "project state"

What belongs on the Instructions page varies by project type — a software
project tracks different things than a creative-writing project or a
business idea. Only track categories that actually apply to *this*
project, rather than guessing or importing categories from a different
project.

Regardless of project type, one thing is constant: **open TODOs/unfinished
work never get their own Instructions-page section.** That category has a
single dedicated home — the Backlog page. If you're about to write "next
steps" or "still to figure out" prose into Instructions, stop and route it
to Backlog instead. Instructions may still contain narrative continuity
about a *currently active* topic (why it's undecided, scope notes, context
a future session needs) — that's not a checklist, it's the story behind one
line in the backlog.

## Noticing drift

At the Claude-solicited checkpoint, do a cheap staleness check before
asking — don't just fire the generic prompt every time:

- Compare what was actually discussed/decided in the current conversation
  against what's already written on the Design Decisions and Backlog
  pages.
- If something discussed this session contradicts or supersedes something
  already written, name that specific gap when soliciting the update
  instead of asking generically (e.g., "we changed our mind on X since
  Design Decisions still says Y — want me to update that too?").
- Reconcile sections, not just facts: **add** a section for a topic that
  now applies but isn't documented yet, **remove** a section whose topic no
  longer applies, and **update** a section whose content is stale but still
  relevant. Propose all three kinds of changes together rather than only
  ever appending.
- This only changes *what you ask* — the hard rule still applies: never
  write without explicit go-ahead.
- **Self-report the drift check itself**, every run: when proposing the
  plan, include a visible summary of which pages were checked and the
  finding for each — including an explicit "no drift" where nothing was
  found — not just the resulting proposed edits.

**Full drift-pass, not just session-triggered:** don't only check Design
Decisions against *this session's* work — that misses staleness in
sections nobody touched recently. At every Claude-solicited checkpoint, do
one pass over the full Design Decisions page, not just the parts relevant
to today, and flag anything that contradicts current reality even if this
session didn't cause it.

## Keeping the Backlog and Activity Log pages in sync

Treat every run of this skill as a pass over the whole page set, not just
the Instructions page:

- **Backlog page** — check off items the session's work resolved, add any
  new items it surfaced, and re-prioritize if the session changed what's
  next. Do not create or maintain a second checklist anywhere else.
- **Activity Log page** — prose only: current-state summary + a
  per-session changelog entry (newest-first). No checklist section belongs
  here — if about to write a checkbox-style item into this page, it
  belongs on Backlog instead.
- **Design Decisions page** — locked decisions only. If the session's work
  resolved, added, or contradicted something documented there, flag it and
  propose the edit. If a "decision" there is actually still open (a
  flagged risk, a deferred alternative, an unresolved question), that's a
  backlog item wearing the wrong hat — propose moving it to Backlog rather
  than leaving it here.
- Bundle all of it — Instructions, Backlog, Activity Log, and Design
  Decisions if any need a touch — into the **same** proposed plan and the
  same go-ahead. Don't get approval on one page alone and then separately
  edit the others unprompted afterward.

## Notion-specific mechanics

- Fetch current page content before proposing an edit — never propose
  changes from memory alone, since the page may have been edited outside
  this conversation.
- Prefer targeted content updates or appends over full-page replacement
  where possible, to avoid accidentally clobbering unrelated sections.
- Treat each of the four pages as its own isolated edit target — fetch and
  update only the specific page(s) relevant to the proposed change, not the
  whole hub tree at once.
- If working across multiple Notion-tracked projects, always confirm which
  project's pages are the target before writing, since page names
  (Instructions, Backlog, etc.) repeat across projects.
